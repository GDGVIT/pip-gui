import os
os.system('curl https://github.com/vinta/awesome-python/blob/master/README.md >> db.txt')
